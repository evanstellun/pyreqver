"""Version information for pyreqver package."""

__version__ = "0.1.0"