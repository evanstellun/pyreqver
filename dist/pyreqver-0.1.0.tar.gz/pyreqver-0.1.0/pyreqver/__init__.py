"""PyReqVer - Python Requirements Version Checker

PyReqVer is a command-line tool that helps you find Python versions that support all libraries in your requirements.txt file.
"""

__version__ = "0.1.0"